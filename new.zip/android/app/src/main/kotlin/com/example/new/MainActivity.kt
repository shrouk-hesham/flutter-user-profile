package com.example.new

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
