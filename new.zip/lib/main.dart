import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return new MaterialApp(
      home: SafeArea(
          child: Scaffold(
        backgroundColor: Colors.teal,
        //appBar: AppBar(
        //title: Text('profile app'),
        //centerTitle: true,
        //backgroundColor: Colors.teal,
        //),
        body: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          CircleAvatar(
            radius: 80,
            //backgroundColor: Colors.pink,
            backgroundImage: AssetImage('images/image.jpg'),
          ),
          SizedBox(
            height: 10,
          ),
          Text('Flutter developer',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          Divider(),
          Container(
            color: Colors.white,
            margin: EdgeInsets.all(10),
            padding: EdgeInsets.all(10),
            child: Row(
              children: [
                Icon(Icons.phone),
                SizedBox(
                  width: 20,
                ),
                Text(
                  '01002030505',
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                  //style: TextStyle(fontsize:20,fontweigt: Fontweight.bold),
                ),
              ],
            ),
          ),
          Container(
            color: Colors.white,
            margin: EdgeInsets.all(10),
            padding: EdgeInsets.all(10),
            child: Row(
              children: [
                Icon(Icons.email),
                SizedBox(
                  width: 20,
                ),
                Text(
                  'shroukhesham@gmail.com',
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                  //style: TextStyle(fontsize:20,fontweigt: Fontweight.bold),
                ),
              ],
            ),
          )
        ]),
      )),
    );
  }
}
